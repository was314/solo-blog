title: CentOS7 安装 Redis
date: '2019-10-10 10:44:05'
updated: '2019-10-10 10:44:20'
tags: [CentOS7, redis]
permalink: /articles/2019/10/10/1570675445009.html
---
# CentOS7 安装 Redis
## 检查是否有redis yum 源
```
yum install redis
```
## 下载fedora的epel仓库
```
yum install epel-release
```
## 安装redis
```
yum install redis
```
## 开启远程连接
```
# 打开redis配置文件
vim /etc/redis.conf
# 找到 bind 127.0.0.1 将其注释
# 找到 protected-mode yes 将其改为
protected-mode no
```
## 启动redis服务
```
# 启动redis
service redis start
# 停止redis
service redis stop
# 查看redis运行状态
service redis status
# 查看redis进程
ps -ef | grep redis
#设置redis为开机自动启动
chkconfig redis on
```
