title: Centos安装Java，配置环境变量
date: '2019-09-29 14:23:12'
updated: '2019-09-29 14:23:12'
tags: [Centos, Java]
permalink: /articles/2019/09/29/1569738192216.html
---
# Centos安装Java，配置环境变量
## 卸载系统自带的JDK
### 检查自带JDK及版本信息
```
 java -version
```
![1.jpg](https://img.hacpai.com/file/2019/09/1-f54f2672.jpg)

### 查询JDK文件
```
yum list instaled | grep java
```
![2.jpg](https://img.hacpai.com/file/2019/09/2-9f820727.jpg)

### 删除JDK文件
```
yum -y remove java-1.7.0-openjdk*
yum -y remove java-1.8.0-openjdk*
```
### 验证删除结果
#### 查看JDK文件是否还存在,Java命令是否还能执行
![3.jpg](https://img.hacpai.com/file/2019/09/3-54bf0cf0.jpg)

## 利用yum命令下载安装JDK(无需配置环境变量,安装过程自动配置)
### 查看yum库中的JDK安装包
```
yum -y list java*
```
![4.jpg](https://img.hacpai.com/file/2019/09/4-c71506f4.jpg)

### 安装所需版本的JDK程序
```
yun -y install java-1.8.0-openjdk*
```
![5.jpg](https://img.hacpai.com/file/2019/09/5-07e4fd76.jpg)

### 安装完成后 , 默认安装位置为 /usr/lib/jvm/java-1.8.0-openjdk*/
![6.jpg](https://img.hacpai.com/file/2019/09/6-e1a13a66.jpg)

## 测试JDK是否配置成功
```
java -version
javac -version
```
![7.jpg](https://img.hacpai.com/file/2019/09/7-9cf71ba4.jpg)


