title: Docker安装配置
date: '2019-09-29 14:17:08'
updated: '2019-10-14 15:02:34'
tags: [docker]
permalink: /articles/2019/09/29/1569737828587.html
---
# Docker安装配置
## 卸载旧版本
```
yum remove docker \
				  docker-client \
				  docker-client-latest \
				  docker-common \
				  docker-latest \
				  docker-latest-logrotate \
				  docker-logrotate \
				  docker-selinux \
				  docker-engine-selinux \
				  docker-engine
```
## 使用 yum 安装
### 安装依赖包
```
yum install -y yum-utils \
           device-mapper-persistent-data \
           lvm2
```
### 添加 yum 软件源
```
yum-config-manager \
    --add-repo \
    https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo


# 官方源
# $ sudo yum-config-manager \
#     --add-repo \
#     https://download.docker.com/linux/centos/docker-ce.repo
```
### 配置缓存 
```
yum makecache fast
```
### 安装最新稳定版本的docker
```
yum install -y docker-ce
```
### 配置镜像加速器
```
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["http://hub-mirror.c.163.com"]
}
EOF
```
### 启动docker引擎并设置开机启动
```
sudo systemctl start docker
sudo systemctl enable docker
```

## 安装 docker-compose
### 下载 1.24.1 版本 docker-compose 到 /usr/local/bin 目录
```
sudo curl -L "https://github.com/docker/compose/releases/download/1.24.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```
### 增加权限
```
chmod +x /usr/local/bin/docker-compose
```
### 验证安装
```
$ docker-compose --version
docker-compose version 1.24.1, build 1110ad01
```
