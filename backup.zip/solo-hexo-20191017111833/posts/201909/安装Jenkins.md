title: 安装 Jenkins
date: '2019-09-29 14:25:14'
updated: '2019-09-29 14:25:14'
tags: [Jenkins]
permalink: /articles/2019/09/29/1569738314082.html
---
# 安装
## 安装Jenkins
```
	docker run --name devops-jenkins --user=root -p 8080:8080 -p 50000:50000 -v /opt/data/jenkins_home:/var/jenkins_home -d jenkins/jenkins:lts
```
## Jenkins配置
* 初始化jenkins及安装插件
	* 浏览器输入 ip+端口
	
	![3.jpg](https://img.hacpai.com/file/2019/09/3-9026321e.jpg)

	* 根据提示从输入administrator password 或者可以通过启动日志
	```
		docker logs devops-jenkins
	```
	![1.jpg](https://img.hacpai.com/file/2019/09/1-f39f6181.jpg)

	* 选择安装插件方式，这里我是默认第一个
	![2.jpg](https://img.hacpai.com/file/2019/09/2-8f22a5f9.jpg)

	* 进入插件安装界面，连网等待插件安装
	![4.jpg](https://img.hacpai.com/file/2019/09/4-5f9b4602.jpg)

	* 安装完插件后，进入创建管理员界面
	![5.jpg](https://img.hacpai.com/file/2019/09/5-1e6147c1.jpg)

	* 输入完管理员账号后，点击continue as admin
	* 跳转登陆界面
	![6.jpg](https://img.hacpai.com/file/2019/09/6-a1cf845b.jpg)

	* 编辑 jenkins_home 目录下 config.xml 文件
	![8.jpg](https://img.hacpai.com/file/2019/09/8-be7ec260.jpg)

	* 删除文件中的以下代码，并保存文件
	![7.jpg](https://img.hacpai.com/file/2019/09/7-3799121c.jpg)

	* 重启Jenkins服务
	* 进入首页 > 系统管理 > 全局安全配置
	![9.jpg](https://img.hacpai.com/file/2019/09/9-9fbaea08.jpg)

	* 启用安全，专有用户数据库
	![10.jpg](https://img.hacpai.com/file/2019/09/10-f5c7a8cc.jpg)

	* 管理用户
	![12.jpg](https://img.hacpai.com/file/2019/09/12-ecebd6ef.jpg)

	* 重新修改密码
	![11.jpg](https://img.hacpai.com/file/2019/09/11-a5774424.jpg)

