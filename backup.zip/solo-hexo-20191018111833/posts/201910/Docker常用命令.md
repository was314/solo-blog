title: Docker 常用命令
date: '2019-10-14 15:01:16'
updated: '2019-10-14 15:02:17'
tags: [Docker]
permalink: /articles/2019/10/14/1571036476649.html
---
# docker 命令
## images 镜像
* 查看所有镜像
```
docker images
```
* 删除镜像
```
docker rmi -f [IMAGE ID]

docker rmi $(docker images -q)  ##删除所有镜像
```
* build
```
docker build -t test/wit:0.1 .
```

* 通过镜像创建docker 容器 并启动  
```
docker run --restart=always -d -p 80:80 -p 443:443 -p 22:22 test/wit:0.1
```


## containers  容器
* 查看所有docker容器
```
docker ps -a
```
* 终止容器
```
docker stop $CONTAINER_ID
docker stop $(docker ps -aq)   ##停止所有容器
```
* 删除容器
```
docker rm $CONTAINER_ID
docker rm $(docker ps -aq)   ##删除所有容器
```
* 重新启动容器容器
```
docker restart $CONTAINER_ID
```
* 查看输出
```
$ docker logs $CONTAINER_ID 	##在container外面查看它的输出 
$ docker attach $CONTAINER_ID 	##连接上容器实时查看
```

* 进入正在运行的容器
```
docker exec -it $CONTAINER_ID /bin/bash
```

* 设置容器开机启动
```
docker update --restart=always <CONTAINER ID>
```

## 其它
* 查看 windows 端口占用
```c
netstat -ano|findstr "8080"
netstat -anp|grep 8080
```
* 查看 Linux 发行版本
```c
cat /etc/os-release
```
* 修改 Linux 时区
```c
apt-get update					# 更新 apt-get 资源
apt-get install tzdata 			# 用 apt-get 安装 tzdata
dpkg-reconfigure tzdata			# 用 tzdata 设置系统时区
```
* 查看硬盘
```
 df -hl
```
