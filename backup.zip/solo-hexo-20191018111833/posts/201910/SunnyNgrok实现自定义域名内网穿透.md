title: Sunny-Ngrok实现自定义域名内网穿透
date: '2019-10-17 11:10:36'
updated: '2019-10-17 11:12:09'
tags: [Sunny-Ngrok, 内网穿透]
permalink: /articles/2019/10/17/1571281836502.html
---
# Sunny-Ngrok实现自定义域名内网穿透
### 注册Sunny-Ngrok [官网](https://www.ngrok.cc)
### 登陆Sunny-Ngrok后台 [后台地址](https://www.ngrok.cc/user)
### 隧道管理 - 开通隧道
![1.jpg](https://img.hacpai.com/file/2019/10/1-e11add85.jpg)

### 添加隧道
![2.jpg](https://img.hacpai.com/file/2019/10/2-9e8cc526.jpg)~~~~

### 隧道管理 - 编辑
> 选择使用自定义域名

> 按提示修改CNAME

# Centos 运行 Sunny-Ngrok ， 设置开机启动
### 下载客户端	[Ngrok客户端下载](https://www.ngrok.cc/download.html)
### 将客户端执行文件移动到 /use/local/bin 目录下并给予可执行权限
```
mv sunny /usr/local/bin/sunny

chmod +x /usr/local/bin/sunny
```
### 编写启动脚本
```
vim /etc/init.d/sunny
```
> /etc/init.d/sunny 启动脚本代码
```
#!/bin/sh -e
### BEGIN INIT INFO
# Provides:          ngrok.cc
# Required-Start:    $network $remote_fs $local_fs
# Required-Stop:     $network $remote_fs $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: autostartup of ngrok for Linux
### END INIT INFO

DAEMON=/usr/local/bin/$NAME
PIDFILE=/var/run/$NAME.pid

[ -x "$DAEMON" ] || exit 0
case "$1" in
  start)
      if [ -f $PIDFILE ]; then
        echo "$NAME already running..."
        echo -e "\033[1;35mStart Fail\033[0m"
      else
        echo "Starting $NAME..."
        start-stop-daemon -S -p $PIDFILE -m -b -o -q -x $DAEMON -- clientid 隧道id || return 2
        echo -e "\033[1;32mStart Success\033[0m"
    fi
    ;;
  stop)
        echo "Stoping $NAME..."
        start-stop-daemon -K -p $PIDFILE -s TERM -o -q || return 2
        rm -rf $PIDFILE
        echo -e "\033[1;32mStop Success\033[0m"
    ;;
  restart)
    $0 stop && sleep 2 && $0 start
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    exit 1
    ;;
esac
exit 0
```
> 把代码里面的【隧道id】替换成自己的隧道id
### 测试可执行代码
```
chmod 755 /etc/init.d/sunny
/etc/init.d/sunny start
/etc/init.d/sunny start    #启动
/etc/init.d/sunny stop     #停止
/etc/init.d/sunny restart  #重启
```
### 设置开机启动
> Centos 7
```
chkconfig --add sunny     #添加系统服务
chkconfig --del sunny    #删除系统服务
chkconfig --list        #查看系统服务
chkconfig sunny on     #设置开机启动
chkconfig sunny off     #设置取消启动
service sunny start         #启动
service sunny stop             #关闭
service sunny restart         #重启
```
### Centos安装 start-stop-daemon
```
wget http://developer.axis.com/download/distribution/apps-sys-utils-start-stop-daemon-IR1_9_18-2.tar.gz

tar -xzvf apps-sys-utils-start-stop-daemon-IR1_9_18-2.tar.gz

# 然后进入解压之后的路径 一直 cd 到start-stop-daemon.c在的目录 
cc start-stop-daemon.c -o start-stop-daemon

cp start-stop-daemon /usr/bin/start-stop-daemon
```

